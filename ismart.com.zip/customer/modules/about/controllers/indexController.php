<?php

function construct() {
    
}

function indexAction() {
    load_view('index');
}

function addAction() {
    
}

function editAction() {

}