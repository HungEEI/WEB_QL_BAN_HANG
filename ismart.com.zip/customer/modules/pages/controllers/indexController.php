<?php

function construct() {

}

function aboutAction() {
    load_view('about');
}

function contactAction() {
    load_view('contact');
}


